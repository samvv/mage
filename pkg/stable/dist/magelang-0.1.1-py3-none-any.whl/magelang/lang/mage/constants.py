
unit_rule_name = 'void'
string_rule_type = 'String'
integer_rule_type = 'Integer'

builtin_types = {
    unit_rule_name,
    string_rule_type,
    integer_rule_type,
}

