
import sys

from magelang import main

sys.exit(main())
